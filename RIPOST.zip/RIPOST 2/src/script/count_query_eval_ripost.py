import sys
from pathlib import Path
sys.path.append(str(Path('').resolve()))
import numpy as np
import pandas as pd
import time
from tqdm import tqdm
from pathlib import Path

import argparse
from src.hdpview import *
from src.hdpview.dataset import Dataset
from src.hdpview.workload_generator import *

from src.RIPOST import ripost_run

if __name__ == '__main__':
    for name_dataset_exp in tqdm(["nume-adult","adult","small-adult","gowalla-2d","jm","mini-fire"],"Dataset loop : ",leave=False):#

        root_dir = Path('__file__').resolve().parent
        
        data_dir = root_dir / "data" / "preprocessed" / name_dataset_exp
    
        data = Dataset.load(data_dir / 'data.csv', data_dir / 'domain.json')

        epsilon = 0.1

        

        direct_workloads = [] #  using direct representation, instead using matrix representation for range query for speed up
        implicit_workloads = []

        
            
        for i in range(1):
                if name_dataset_exp =="adult":
                    direct_workloads.append(direct_random_range_queries(domain=data.domain, size=3000, dim_size=7, seed=i,one=True))
                    direct_workloads.append(direct_random_range_queries(domain=data.domain, size=3000, dim_size=8, seed=i,one=True))
                    direct_workloads.append(direct_random_range_queries(domain=data.domain, size=3000, dim_size=9, seed=i,one=True))
                    direct_workloads.append(direct_random_range_queries(domain=data.domain, size=3000, dim_size=10, seed=i,one=True))
                    direct_workloads.append(direct_random_range_queries(domain=data.domain, size=3000, dim_size=11, seed=i,one=True))
                    direct_workloads.append(direct_random_range_queries(domain=data.domain, size=3000, dim_size=12, seed=i,one=True))
                    direct_workloads.append(direct_random_range_queries(domain=data.domain, size=3000, dim_size=13, seed=i,one=True))
                    direct_workloads.append(direct_random_range_queries(domain=data.domain, size=3000, dim_size=14, seed=i,one=True))
                elif name_dataset_exp == "mini-fire" :
                    direct_workloads.append(direct_random_range_queries(domain=data.domain, size=3000, dim_size=2, seed=i))
                    direct_workloads.append(direct_random_range_queries(domain=data.domain, size=3000, dim_size=3, seed=i))
                    direct_workloads.append(direct_random_range_queries(domain=data.domain, size=3000, dim_size=4, seed=i))
                    direct_workloads.append(direct_random_range_queries(domain=data.domain, size=3000, dim_size=5, seed=i))
                    direct_workloads.append(direct_random_range_queries(domain=data.domain, size=3000, dim_size=6, seed=i))
                elif name_dataset_exp == "jm" :
                    direct_workloads.append(direct_random_range_queries(domain=data.domain, size=3000, dim_size=2, seed=i,one=True))
                    direct_workloads.append(direct_random_range_queries(domain=data.domain, size=3000, dim_size=3, seed=i,one=True))
                    direct_workloads.append(direct_random_range_queries(domain=data.domain, size=3000, dim_size=4, seed=i,one=True))
                    direct_workloads.append(direct_random_range_queries(domain=data.domain, size=3000, dim_size=5, seed=i,one=True))
                    direct_workloads.append(direct_random_range_queries(domain=data.domain, size=3000, dim_size=6, seed=i,one=True))
                elif name_dataset_exp == "small-adult" :
                    direct_workloads.append(direct_random_range_queries(domain=data.domain, size=3000, dim_size=2, seed=i,one=True))
                    direct_workloads.append(direct_random_range_queries(domain=data.domain, size=3000, dim_size=3, seed=i,one=True))
                    direct_workloads.append(direct_random_range_queries(domain=data.domain, size=3000, dim_size=4, seed=i,one=True))
                elif name_dataset_exp == "gowalla-2d":
                      direct_workloads.append(direct_random_range_queries(domain=data.domain, size=3000, dim_size=2, seed=i))
                else :
                    direct_workloads.append(direct_random_range_queries(domain=data.domain, size=3000, dim_size=2, seed=i))
                    direct_workloads.append(direct_random_range_queries(domain=data.domain, size=3000, dim_size=3, seed=i))
                    direct_workloads.append(direct_random_range_queries(domain=data.domain, size=3000, dim_size=4, seed=i))
                    direct_workloads.append(direct_random_range_queries(domain=data.domain, size=3000, dim_size=5, seed=i))
                    direct_workloads.append(direct_random_range_queries(domain=data.domain, size=3000, dim_size=6, seed=i))
                    
                    direct_workloads.append(direct_random_range_queries(domain=data.domain, size=100, dim_size=2, seed=i,one=True))
                    direct_workloads.append(direct_random_range_queries(domain=data.domain, size=100, dim_size=3, seed=i,one=True))
                    direct_workloads.append(direct_random_range_queries(domain=data.domain, size=100, dim_size=4, seed=i,one=True))
                    direct_workloads.append(direct_random_range_queries(domain=data.domain, size=100, dim_size=5, seed=i,one=True))
                    direct_workloads.append(direct_random_range_queries(domain=data.domain, size=100, dim_size=6, seed=i,one=True))
                

        for j in tqdm(range(len(direct_workloads)),"direct-workload loop ",leave=True):
        
                    direct_workload_name, direct_workload = direct_workloads[j]
                    beta= .4
                    alpha = .3
                    gamma = .9
                    step =1
                    rmse_g,_,compressions,view_times,_ = ripost_run.run(data,epsilon,direct_workload,name_dataset_exp,direct_workload_name,[beta,step],False,[0,gamma,alpha,0])
                        
                    data_sensi = {
                                        "RMSE" : rmse_g,
                                    }
                    df = pd.DataFrame(data_sensi)
                    df.to_csv("exp-RIPOST-"+name_dataset_exp+"-"+direct_workload_name+".csv")

                    

                
