import numpy as np
import multiprocessing
import functools
import itertools

import random

from src.hdpview.count_table import NoisedCountTable, BlockResult, calculate_mean_and_aggregation_error,calculate_ae_from_data

def run(block, epsilon, ratio, prng, alpha=2, beta=1.2, gamma=1.0, ratios=[.11,.11], theta=None, verbose=False):
    """Run HDPView
        1st phase, divide blocks.
        2nd phase, perturbation.
        Prepare parameters and execute HDPView

    Args:
        block (CountTable): block
        epsilon (float): privacy budget
        ratio (float): ubdget ratio of block division and perturbation, 0 to 1 value
        prng (np.random.RandomState): random state
        alpha (float), beta(float), gamma(float)
        verbose (bool)
    """
    seed = prng.randint(0, 2949672950)
    block.set_random(seed)

    
    block.conv_pop = False
    block.conv_pop_d = 0
    block.ae =0

    if verbose:
        print("seed: ", seed)

    n_dash = block.size() #domain size

    step = ratios[1]

    
    epsilon_r = epsilon * ratio
    adds =   gamma * epsilon_r  - gamma * epsilon_r /step # By default this step is equal to 1, this line 
    epsilon_p = epsilon * (1 - ratio) + adds
    if theta is None:
        theta = 0#1/epsilon_p

    epsilon_cut = (1 - gamma) * epsilon_r 
    epsilon_conv = gamma * epsilon_r /step

    budget_phase_1 = [epsilon_conv*ratios[0], epsilon_cut*ratios[0]]
    budget_phase_2 = [epsilon_conv*(1 - ratios[0]), epsilon_cut*(1 - ratios[0])]



    # prepare shared memories for parallelization
    manager = multiprocessing.Manager()
    block_queue = manager.Queue()
    block_queue.put(block)
    block_result_list = []
    
    MAX_PROCESS = multiprocessing.cpu_count()-1
    pool = multiprocessing.Pool(1)
    
    while True:
        async_results = []
        while not block_queue.empty():
            result = pool.apply_async(
                recursive_bisection, (block_queue.get(), block_queue, epsilon_cut, 0, theta, budget_phase_1, budget_phase_2,epsilon_conv ,block,step,verbose)
            )
            async_results.append(result)
        results = list(itertools.chain.from_iterable([ r.get() for r in async_results ]))
        block_result_list.extend(results)
        if block_queue.empty():
            break

    block_result_list.sort(key=functools.cmp_to_key(range__gt__))

    for block_result in block_result_list:
        mean,median,sum, ae,ae_me, non_empty,empty = calculate_mean_and_aggregation_error(block, block_result.domain_dict)
        if ae != block_result.ae or mean != block_result.mean:
            ae = ae
        
        sensitivity = 1 
        block_result.empty=empty
        block_result.non_empty = non_empty
        block_result.mean = block_result.mean
        block_result.reel_sum = sum
        block_result.aggregation_error_mean = ae
        block_result.aggregation_error = block_result.ae
        block_result.aggregation_error_median = ae_me
        pe = np.random.laplace(0,sensitivity / epsilon_p) 
        block_result.perturbation_error = pe

        ## Add more infos for better understanding of the early convergence
        ### Stats
        mean,median,sum_block, ae,ae_me,non_empty,empty = calculate_mean_and_aggregation_error(block, block_result.domain_dict)
        block_result.sum_block = sum_block
        block_result.empty = empty
        block_result.non_empty = non_empty
        block_result.median = median
        

        
    return NoisedCountTable.from_count_table(block, block_result_list), block_result_list



    


def recursive_bisection(block, block_queue, epsilon_cut, depth_max, theta, budget_phase_1, budget_phase_2,epsilon_conv, block_ref,step=1,verbose=False):
    """Random cut and random converge

    Args:
        block_queue (multiprocessing.Queue): Shared queue to store blocks to be executed

    Returns:
        [{"range": {int: (int,int)}, "mondrian_budget": float, "depth": int}]
    """
    try:
        
        x=1
        if block.conv_pop: # this is a negation don't get confused
            x = cut_exp_mech_population(block,budget_phase_2[1],0)
        else:
            x = cut_exp_mech_population(block,budget_phase_1[1],1)

        
        converged_block_results = []
        no_split = False
        if x == 1:
            print()
        elif x == 0:
            res= BlockResult(block.domain_dict, block.depth)
            ae,mean = calculate_ae_from_data(block_ref, block.domain_dict)
            res.conv_pop_d  = block.conv_pop_d 
            res.ae = ae
            res.mean = mean
            converged_block_results.append(res)
        else:
            axis, index = x
            left_block, right_block = block.split2(axis, index)

            left_block.conv_pop = block.conv_pop
            right_block.conv_pop = block.conv_pop
            left_block.conv_pop_d  =block.conv_pop_d 
            right_block.conv_pop_d =block.conv_pop_d 

            left_block.ae =0
            right_block.ae =0


            if left_block.size() == 1:
                res= BlockResult(left_block.domain_dict, left_block.depth)
                _,mean,_,_ = calculate_ae_from_data(block_ref, left_block.domain_dict)
                res.conv_pop_d  = left_block.conv_pop_d 
                res.ae = 0
                res.mean = mean
                converged_block_results.append(res)
                

            elif random_converge_pop_lap(left_block,left_block.depth,theta,budget_phase_1[0],block_ref,step) and random_converge_lap(left_block, left_block.depth, theta, budget_phase_2[0],block_ref,step):
                res= BlockResult(left_block.domain_dict, left_block.depth)
                res.conv_pop_d  = left_block.conv_pop_d
                res.ae = left_block.ae
                res.mean = left_block.mean
                converged_block_results.append(res)
            else:
                block_queue.put(left_block)

            if right_block.size() == 1:
                res= BlockResult(right_block.domain_dict, right_block.depth)
                _,mean,_,_ = calculate_ae_from_data(block_ref, right_block.domain_dict)
                res.conv_pop_d  = right_block.conv_pop_d 
                res.ae = 0
                res.mean = mean
                converged_block_results.append(res)
            elif random_converge_pop_lap(right_block, right_block.depth, theta, budget_phase_1[0],block_ref,step) and random_converge_lap(right_block, right_block.depth, theta, budget_phase_2[0],block_ref,step):
                res= BlockResult(right_block.domain_dict, right_block.depth)
                res.conv_pop_d  = right_block.conv_pop_d 
                res.ae = right_block.ae
                res.mean = right_block.mean
                converged_block_results.append(res)
            else:
                block_queue.put(right_block)
    except Exception as e:
        print(e.with_traceback(0))
        raise e

    return converged_block_results


def range__gt__(block_result, other):
    for dim, dom_range in block_result.domain_dict.items():
        other_range = other.domain_dict[dim]
        if dom_range > other_range:
            return 1
        elif dom_range < other_range:
            return -1
    return 0


def exp_mech(prng, eps , scores, targets, sensitivity=1):
    """Exponential mechanism
    """
    try:
        if sensitivity == 0:
            index = prng.choice(len(targets))
            return targets[index]

        np_scores = np.array(scores)
        score_max = np.max(np_scores)
        weights = np.exp((eps*(np_scores - score_max)) / (2*sensitivity))
        total_weight = np.sum(weights)
        cum_weights = weights / total_weight
        possibs = [i for i in range(len(targets))]
        rand_i = np.random.choice(possibs,1,p=cum_weights)[0]
        target = targets[rand_i]
        return target #targets[selected]
    except Exception as e:
        print("Error in Ecp mech")
        return 0




def cut_exp_mech_population(block,epsilon_cut_per_depth,with_pop = True):
    sensitivity = 1
    descaling_factor = 1
    block.depth = np.max([block.depth,1])
    d= block.depth
    if not with_pop:
        d = (d  - block.conv_pop_d) + 1 # to reset the counter for the second phase
    
    d +=3 # offset os
    
    epsilon_cut_per_depth = epsilon_cut_per_depth * 4/(d*(d+1))
    try:
        scores = []
        targets = []
        for d_i,d in enumerate(block.index): # for each dimension
            cardinality = block.cardinality_dict[d]
            if cardinality > 1:
                for i in np.arange(cardinality-1):
                        if with_pop:
                            (left_f,left_e,right_f, right_e) = block.split_values_with_population(d,i) 
                            min_L = np.min([left_e,left_f])
                            min_R = np.min([right_f, right_e])
                            score =  min([min_L,min_R]) # + min_L + min_R  
                            scores.append(-score * descaling_factor)
                            targets.append((d,i))
                        else:
                           
                            vals =  block.split_values(d, i)
                            score = np.sum(vals)
                            scores.append(- score)
                            sensitivity = 2*(2 - 2/block.size())
                            
                            targets.append((d,i))
                            

    except Exception as e:
        print(e)
        raise Exception('Error in cut Exp Mech1')

    if len(scores) > 0:
        
        try:
            return exp_mech(
                block.prng,
                epsilon_cut_per_depth, 
                scores,
                targets,
                sensitivity*descaling_factor
                )
        except Exception as e:
            return 0
            
    else:
        return 0




def random_converge_pop_lap(block,depth,theta, budget,block_ref,step):
    if not block.conv_pop:
        try:
            depth= np.max([depth ,1]) # because it starts at 0
            ###################################################################################################################################################
            ############## Here is the code that adds the step to the convergence condition discussed in the Discussion section of the paper  ###############
            noise_it = True
            # if depth % step !=1 and step !=1: ## This is the skip
            #     noise_it = False
            # depth = (depth // step) + 1 ## To resest the depth to the actuel time to do CC
            ####################################################################################################################################################


            depth +=3 # to make sure that the sum is still 1 given the modified series
            eps_k = budget * (4 / (depth * (depth + 1)))
            if eps_k == 0:
                print("")
            
            _,_,v,zero_num = calculate_ae_from_data(block_ref, block.domain_dict)
            sum = np.sum(v)

            noise = block.prng.laplace(0.0, scale=1/eps_k)

            noisy_sum = sum + noise
            if noise_it:
                block.conv_pop =  (noisy_sum <= theta) #(purity >= 1 )# #or ratio_zoros < .05)
            else:
                return False
                block.conv_pop = (sum <= theta)
            
            if block.conv_pop:
                block.conv_pop_d  = depth - 3 # this is necessary to restart the depth for the second phase of convergence
                
            return block.conv_pop
        except Exception as e:
            print(e.with_traceback())
    else:
        return block.conv_pop



def random_converge_lap(block,depth,theta, budget,block_ref,step):
    try:

        depth  =  np.max([(depth  - block.conv_pop_d) + 1,1 ])# this is useful to restart the depth for the second phase.

        #############################################################################################################################################################
        ############## Here is the code that adds the step to the convergence condition discussed in the Discussion section of the paper  ############################
        noise_it = True
        # if depth % step !=1 and step !=1: ## This is the skip
        #     noise_it =  False
        # depth = (depth // step) + 1 ## To resest the depth to the actuel time to do CC
        #########################################################################################################################################################################

        depth +=3 # to make sure that the sum is still 1 given the modified series

        eps_k = budget * (4 / (depth * (depth + 1)))
        if eps_k ==0:
            print("")

        ae,mean,values,zero_num = calculate_ae_from_data(block_ref, block.domain_dict)
        block.ae = ae
        block.mean = mean
        
        scale = 2/eps_k
        
        ae_noisy = ae + block.prng.laplace(0.0, scale=scale)
        if noise_it:
            conv = (ae_noisy <= theta)
        else:
            return False
            conv = (ae <= theta)
        
        return conv
    except Exception as e:
        print(e.with_traceback())
        # return True




