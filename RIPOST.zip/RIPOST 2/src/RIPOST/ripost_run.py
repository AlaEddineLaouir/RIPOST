import sys
import time
import pickle

import numpy as np
import math
from src.hdpview.dataset import Dataset
from src.hdpview.count_table import CountTable

from src.RIPOST import RIPOST

from src.hdpview.domain import Domain
from tqdm import tqdm

import pandas as pd
# from algorithms.privtree import plot_data

def run(dataset_org,epsilon,workloads,dataset_name,exp_name,ratios,synth,hyper_params = [1.6,0.9,0.5,2.1]):
    rmse_g = []
    number_blocs =[]
    re_g=[]
    compressions =[]
    view_times =[]
    workloads_times=[]
    agg_err_mean=[]
    agg_err_med=[]
    for indice  in tqdm(range(0,len(workloads)),"direct-workload loop : ",leave=True):
        workload  = workloads[indice]
        ratio = hyper_params[2]
        alpha=hyper_params[0]
        beta=hyper_params[3]
        gamma=hyper_params[1]
        

        dataset = dataset_org.df.copy()
        #workload  = workload[0]
        dims = get_attribut_qwl(workload)
        columns_to_drop = [index for index,value in enumerate(dataset.columns) if value not in dims]
        columns_to_not_drop = [index for index,value in enumerate(dataset.columns) if value in dims]
    

        global_dataset =[]
        # (1) Constructing the dataset that will have the same dims as the QWL
        if synth:
            dataset['Mesure'] = np.random.randint(200,2000, size=dataset.shape[0])
            dataset = dataset.drop(dataset.columns[columns_to_drop], axis=1)
            global_dataset = dataset.groupby(dims).sum().reset_index()
            # global_dataset = dataset.copy()
        else:
            
            dataset['Mesure'] = 1
            dataset = dataset.drop(dataset.columns[columns_to_drop], axis=1) 
            global_dataset = dataset.groupby(dims).sum().reset_index()
        # print(global_dataset.shape)

        #mesure = global_dataset['Mesure']

        #print(mesure.var())

        initial_data_size = sys.getsizeof(global_dataset)
        # global_dataset['Mesure'] = 1

        global_dataset_mesure = global_dataset.copy()
        

        rmse = 0
        number = 0
        re=0
        data_comp_ratio =  0
        algo_exe_time = 0
        query_exe_times_true = [0] * len(workload)
        query_exe_times_est = [0] * len(workload)
        query_exe_times_est_t = [0] * len(workload)

        agg_e_mean =0
        agg_e_median =0

        runs =10

        for  iteration  in tqdm(range(runs),"Iterations loop : ",leave=True):

            global_dataset = global_dataset_mesure.copy()
            mesure = global_dataset['Mesure']
            global_dataset.drop('Mesure', axis=1,inplace=True)

           
            # print("size of meseure is : ",len(mesure))
            counts = [dataset_org.domain.shape[index] for index in columns_to_not_drop]
            size__ = 1
            
            for index in columns_to_not_drop:
                size__ *= dataset_org.domain.shape[index]
            
            domain = Domain(global_dataset.columns,counts)
            global_Dataset = Dataset(global_dataset,domain)
            
            
            initial_block = CountTable.from_dataset(global_Dataset)
            initial_block.mesure_table = global_dataset_mesure.copy()


            prng = np.random.RandomState(0)
            view_start_time = time.time()
            
            p_view, block_result_list = RIPOST.run(initial_block,epsilon, ratio, prng, alpha, beta, gamma,ratios)
            
                
            view_end_time=time.time()
            algo_exe_time += (view_end_time - view_start_time)/runs
            
            ###########################
            ## Just some stats #########
            agg_e_mean_sum=0
            agg_e_median_sum=0
            number_of_cells =0
            for b in block_result_list:
                agg_e_mean_sum+= b.aggregation_error_mean
                agg_e_median_sum+=b.aggregation_error_median
                summ=int(b.empty + b.non_empty)
                if int(summ) ==1:
                    number_of_cells+=1
            agg_e_mean += agg_e_mean_sum/runs
            agg_e_median += agg_e_median_sum/runs
            ###########################
            
            number += len(block_result_list) / runs
            result_data_size = sys.getsizeof(p_view)
            data_comp_ratio += (np.abs(len(p_view.blocks) - global_dataset.shape[0])/global_dataset.shape[0])/runs

           

            est = []
            true=[]

            count_blocks_overlap =[]
            for index,query in enumerate(workload):
                res,times = run_query_on_df(global_dataset_mesure,query)
                true.append(res)
                query_exe_times_true[index] = times/runs


                q_start = time.time()
                res, _,overlaps = p_view.run_query(query)
                q_end = time.time()
                count_blocks_overlap.append(np.sum(overlaps))
                est.append(res)
                query_exe_times_est[index] = (q_end-q_start)/runs

            

            est = np.array(est)
            true= np.array(true)
            
            re += ((np.abs(est - true))/np.array([np.maximum(1,x) for x in true]))/runs
            sq_err = np.square(est - true)
            mean_sq_err = np.mean(sq_err)
            rmse += math.sqrt(mean_sq_err)/runs


        compressions.append(data_comp_ratio)
        number_blocs.append(number)
        agg_err_mean.append(agg_e_mean)
        agg_err_med.append(agg_e_median)
        speed_up = np.abs(np.array(query_exe_times_est_t) - np.array(query_exe_times_est))/np.array(query_exe_times_est_t)

        print("======>    The RMSE is : ",rmse)
        
        workloads_times.append([query_exe_times_true,query_exe_times_est])
        view_times.append(algo_exe_time)
        rmse_g.append(rmse)
        re_g.append(re)

    print("======>    The Average RMSE is : ",np.mean(rmse_g))
    return rmse_g,re_g,compressions,view_times,workloads_times,number_blocs,agg_err_mean,agg_err_med


def get_attribut_qwl(workload):
    dims = []
    for cond in workload[0].conditions:
        dims.append(cond.attribute)
    return dims

def run_query_on_df(df,query):
    start_time = time.time()
    boolean_index_org = (df[query.conditions[0].attribute] >= query.conditions[0].start) & (df[query.conditions[0].attribute] <= query.conditions[0].end)
    for cond in query.conditions[1:]:
        boolean_index_org = boolean_index_org & (df[cond.attribute] >= cond.start) & (df[cond.attribute] <= cond.end )           
    res = df[boolean_index_org]['Mesure'].sum()
    end_time = time.time()
    return res, end_time-start_time

def measuring_direct_job(params):
    workload = params
    global global_data, global_noised_data
    est = np.array([ global_noised_data.run_query(query) for query in workload ])
    true = np.array([ global_data.run_query(query) for query in workload ])
    err = np.abs(est - true)
    sq_err = np.square(est - true)
    return err, sq_err


def print_blocks(block_list,meth,dataset):
    means = []
    empty_s= []
    non_empty_s =[]
    sums=[]
    ae_s =[]
    depth_s = []
    depth_c_sum =[]


    for b in block_list:
        means.append(b.mean)
        empty_s.append(b.empty)
        non_empty_s.append(b.non_empty)
        sums.append(int(b.sum_block))
        ae_s.append(b.aggregation_error)
        depth_c_sum.append(b.conv_pop_d)
    
    data_csv = {
        "means" :means,
        "empty_s":empty_s,
        "non_empty_s" :non_empty_s,
        "sums":sums,
        "ae_s":ae_s, 
        "depth_s" :depth_s,
        "depth_sum":depth_c_sum,
    }
    df = pd.DataFrame(data_csv)
    df.to_csv("RIPOST-blocks-"+meth+"-"+dataset+".csv")
