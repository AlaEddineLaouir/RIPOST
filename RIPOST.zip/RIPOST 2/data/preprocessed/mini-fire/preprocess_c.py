import pandas as pd
import json

def transform_csv(input_file, output_csv, output_json):
    # Load the dataset
    df = pd.read_csv(input_file)
    transformed_df = pd.DataFrame()
    domain_info = {}
    
    for i, col in enumerate(df.columns):
        # Get unique values and map them to integer labels starting from 0
        unique_values = df[col].unique()
        value_map = {val: idx for idx, val in enumerate(unique_values)}
        
        # Apply the mapping
        transformed_df[i] = df[col].map(value_map)
        
        # If the column has more than 100 unique values, apply binning
        if len(unique_values) > 100:
            transformed_df[i], bins = pd.cut(transformed_df[i], bins=100, labels=False, retbins=True)
            # transformed_df[i] = transformed_df[i] % 100  # Keep values between 0-99
            domain_info[str(i)] = 100
        else:
            domain_info[str(i)] = len(unique_values)
    
    # Save the transformed dataset
    transformed_df.to_csv(output_csv, index=False)
    
    # Save the domain information as JSON
    with open(output_json, 'w') as json_file:
        json.dump(domain_info, json_file, indent=4)
    
    print("Transformation complete! CSV and JSON files saved.")

# Example usage
transform_csv("fire.csv", "data.csv", "domain_info.json")