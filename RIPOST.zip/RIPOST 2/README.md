# RIPOST (pRivate vIew by two-Phase decompOsition for multidimenSional daTa)

  
This code is associated to the work we submitted to **EDBT 2026**

To run the experiments you need to :
- Install all the rependencies 
> ./install_depnendencies.sh



- Run experiments :
	- RIPOST
	> ./lunch_ripost.sh
	- Partitioning HDPView and PrivTree
		> ./lunch_hdp.sh
        > ./lunch_privtree.sh
	- Workload-dependent HDMM,DAWA and Identity
		> ./lunch_hdmm.sh
	- Generative-model PrivBayes, P3GM
		> Fix the path in the file : src/competitors/privbayes/code/main_marginal.cpp
		>./compile_ektelo_priv.sh
		> ./lunch_gen_exp.sh
	- Generative-model PrivSyn
		> ./lunch_gen_privssyn.sh


Our main codebase is based on the work  done in HDPVIew and SLIMView.
